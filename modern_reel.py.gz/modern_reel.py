import argparse, asyncio, datetime, json, math, os, subprocess, tempfile, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H, FPS, DUR = 1080, 1920, 30, 16.0
FD = ["fonts/", "/usr/share/fonts/truetype/google-fonts/", "/usr/share/fonts/truetype/freefont/"]
def fp(n, fb):
    for d in FD:
        for f in (n, fb):
            if os.path.exists(d + f): return d + f
    raise SystemExit("no font")
BOLD, MED, REG = fp("Poppins-Bold.ttf", "FreeSansBold.ttf"), fp("Poppins-Medium.ttf", "FreeSansBold.ttf"), fp("Poppins-Regular.ttf", "FreeSans.ttf")
BG1, BG2 = np.array([12, 10, 32]), np.array([40, 14, 70])
RED, GREEN, CYAN, YEL, WHITE = (255, 82, 99), (46, 230, 150), (80, 220, 255), (255, 214, 77), (245, 245, 255)

POOL = [
("I am agree", "I agree", "'Agree' khud ek verb hai.", "Isme 'am' nahi lagta!"),
("Discuss about it", "Discuss it", "Discuss ke baad 'about'", "nahi aata. Seedha bolo!"),
("Myself Rahul", "I am Rahul", "Introduction mein 'Myself'", "nahi, 'I am' bolo."),
("I have 20 years", "I am 20 years old", "Age ke liye 'am' aata hai,", "'have' nahi!"),
("He don't like tea", "He doesn't like tea", "He/She/It ke saath", "'doesn't' lagta hai."),
("I am having a car", "I have a car", "Owning ke liye 'have',", "-ing nahi lagta."),
("More better", "Much better", "Better pehle se comparative hai,", "'more' mat lagao."),
("Open the light", "Turn on the light", "Light 'open' nahi hoti,", "'turn on' karte hain."),
("I did not went", "I did not go", "'Did' ke baad verb", "hamesha 1st form mein."),
("Return back", "Return", "'Return' mein 'back'", "pehle se shamil hai."),
("Explain me", "Explain it to me", "Explain ke baad", "'to' zaroori hai."),
("I am knowing", "I know", "'Know' ke saath -ing", "kabhi nahi lagta."),
("Please revert back", "Please reply", "Reply karna hai to", "seedha 'reply' bolo."),
("Where you are going?", "Where are you going?", "Question mein helping verb", "pehle aata hai."),
("Since 2 years", "For 2 years", "'Since' point of time ke liye,", "'for' period ke liye."),
("What is your good name?", "What is your name?", "'Good' lagane ki zaroorat", "nahi, seedha poocho."),
("He is more taller", "He is taller", "Taller pehle se comparative hai,", "'more' mat lagao."),
("Eat medicine", "Take medicine", "Medicine 'take' karte hain,", "'eat' nahi."),
("My hair are long", "My hair is long", "'Hair' uncountable hai,", "isliye 'is' aata hai."),
("Furnitures", "Furniture", "Furniture uncountable hai,", "'s' nahi lagta."),
("Informations", "Information", "Information bhi uncountable hai.", "Kabhi 's' nahi!"),
("I am boring", "I am bored", "Bored = aap thak gaye,", "boring = jo thaka de."),
("An advice", "A piece of advice", "Advice uncountable hai,", "'an' nahi lagta."),
("Go for market", "Go to the market", "'to the' lagta hai,", "'for' nahi."),
("Say me the truth", "Tell me the truth", "Tell ke baad seedha person,", "Say ke baad 'to' aata hai."),
("I enjoyed a lot", "I enjoyed it a lot", "'Enjoy' ke baad object", "zaroori hai."),
("I am doing job", "I have a job", "Job 'have' hoti hai,", "'do' nahi."),
("I am having doubt", "I have a doubt", "'Doubt' ke saath 'have' aata hai,", "'having' nahi."),
("Give exam", "Take an exam", "Exam 'take' karte hain,", "'give' nahi."),
]
SONGS = ["Stronger - Kelly Clarkson", "Fight Song - Rachel Platten", "Roar - Katy Perry", "Believer - Imagine Dragons",
         "Unstoppable - Sia", "Hall of Fame - The Script", "Titanium - David Guetta ft. Sia", "Eye of the Tiger - Survivor"]
SM = [(2.6 + 3.0 * i, 5.6 + 3.0 * i) for i in range(3)]
CTA = 11.6

def eo(t): t = min(max(t, 0), 1); return 1 - (1 - t) ** 3
def eb(t): t = min(max(t, 0), 1); return 1 + 2.70158 * (t - 1) ** 3 + 1.70158 * (t - 1) ** 2

yy = np.linspace(0, 1, H)[:, None, None]
BASE = Image.fromarray(((BG1 * (1 - yy) + BG2 * yy) * np.ones((1, W, 1))).astype(np.uint8)).convert("RGBA")
def glow(c, r):
    g = Image.new("RGBA", (r * 2, r * 2), c + (0,))
    ImageDraw.Draw(g).ellipse([r * .45, r * .45, r * 1.55, r * 1.55], fill=c + (120,))
    return g.filter(ImageFilter.GaussianBlur(r * .2))
G1, G2 = glow((120, 60, 255), 520), glow((0, 200, 255), 420)
def bg(t):
    im = BASE.copy()
    im.paste(G1, (int(W * .1 + 160 * math.sin(t * .7)) - 520, int(H * .15 + 120 * math.cos(t * .5)) - 520), G1)
    im.paste(G2, (int(W * .55 + 140 * math.cos(t * .6)) - 420, int(H * .68 + 160 * math.sin(t * .8)) - 420), G2)
    return im

_c = {}
def timg(txt, size, col, font):
    k = (txt, size, col, font)
    if k not in _c:
        f = ImageFont.truetype(font, size); l, t, r, b = f.getbbox(txt)
        im = Image.new("RGBA", (r - l + 40, b - t + 40), (0, 0, 0, 0))
        ImageDraw.Draw(im).text((20 - l, 20 - t), txt, font=f, fill=col + (255,)); _c[k] = im
    return _c[k]
def fit(txt, maxsize, maxw, font=BOLD):
    sz = maxsize
    while sz > 30 and ImageFont.truetype(font, sz).getlength(txt) > maxw: sz -= 2
    return sz
def put(img, txt, cx, cy, size, col, font=BOLD, a=1.0, s=1.0, dy=0):
    if a <= .01 or s <= .01: return None
    ti = timg(txt, size, col, font)
    if s != 1.0: ti = ti.resize((max(1, int(ti.width * s)), max(1, int(ti.height * s))), Image.LANCZOS)
    if a < 1.0:
        ti = ti.copy(); ti.putalpha(ti.getchannel("A").point(lambda v: int(v * a)))
    x, y = int(cx - ti.width / 2), int(cy - ti.height / 2 + dy)
    img.paste(ti, (x, y), ti); return (x, y, ti.width, ti.height)
def pill(img, cx, cy, w, h, col, a=1.0, fa=60):
    if a <= .01: return
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(lay).rounded_rectangle([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2], radius=h / 2, fill=col + (int(fa * a),), outline=col + (int(255 * a),), width=4)
    img.alpha_composite(lay)
def icon(img, kind, cx, cy, r, a=1.0, prog=1.0):
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(RED if kind == "x" else GREEN) + (int(255 * a),))
    w = int(r * .18); s = r * .42; wc = (255, 255, 255, int(255 * a))
    if kind == "x":
        d.line([cx - s, cy - s, cx + s, cy + s], fill=wc, width=w); d.line([cx + s, cy - s, cx - s, cy + s], fill=wc, width=w)
    else:
        d.line([(cx - s, cy), (cx - s * .25, cy + s * .75), (cx + s, cy - s * .7)], fill=wc, width=w, joint="curve")
    if prog < 1:
        sc = eb(prog); lay = lay.crop((int(cx - r - 10), int(cy - r - 10), int(cx + r + 10), int(cy + r + 10)))
        lay = lay.resize((max(1, int(lay.width * sc)), max(1, int(lay.height * sc))), Image.LANCZOS)
        img.alpha_composite(lay, (int(cx - lay.width / 2), int(cy - lay.height / 2))); return
    img.alpha_composite(lay)

def hook(img, t):
    put(img, "STOP!", W / 2, 640, 190, YEL, a=eo(t / .5), s=.6 + .4 * eb(t / .6))
    for i, (tx, y) in enumerate([("Ye 3 English galtiyan", 900), ("aap roz karte ho", 1010)]):
        u = eo((t - .3 - .2 * i) / .5); put(img, tx, W / 2, y, 78, WHITE, a=u, dy=40 * (1 - u))
    pill(img, W / 2, 1260, 640, 120, CYAN, a=eo((t - 1) / .5)); put(img, "Fix them in 15 sec", W / 2, 1260, 54, CYAN, MED, a=eo((t - 1.1) / .5))

def mistake(img, t, m, i):
    wrong, right, t1, t2 = m
    put(img, f"MISTAKE {i + 1}/3", W / 2, 330, 56, CYAN, MED, a=eo(t / .3))
    a = eo(t / .35); icon(img, "x", 190, 640, 62, a=a)
    box = put(img, wrong, W / 2 + 90, 640, fit(wrong, 92, 700), RED, a=a, dy=80 * (1 - a))
    p = eo((t - 1) / .35)
    if box and p > 0:
        lay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        ImageDraw.Draw(lay).line([box[0] + 10, box[1] + box[3] / 2, box[0] + 10 + (box[2] - 20) * p, box[1] + box[3] / 2], fill=RED + (255,), width=12); img.alpha_composite(lay)
    tr = t - 1.4
    if tr > 0:
        icon(img, "check", 190, 960, 62, a=eo(tr / .2), prog=tr / .4)
        put(img, right, W / 2 + 90, 960, fit(right, 104, 700), GREEN, a=eo(tr / .25), s=.7 + .3 * eb(tr / .45))
    tt = t - 2
    if tt > 0:
        pill(img, W / 2, 1290, 900, 230, WHITE, a=eo(tt / .3), fa=25)
        put(img, t1, W / 2, 1255, 46, WHITE, MED, a=eo(tt / .3)); put(img, t2, W / 2, 1325, 46, YEL, MED, a=eo((tt - .1) / .3))

def cta(img, t):
    put(img, "Roz ek nayi", W / 2, 560, 84, WHITE, a=eo(t / .4))
    put(img, "English trick", W / 2, 680, 112, YEL, a=eo((t - .2) / .4), s=.8 + .2 * eb((t - .2) / .5))
    put(img, "SAVE kar lo", W / 2, 920, 100, GREEN, a=eo((t - .8) / .4), s=.7 + .3 * eb((t - .8) / .5))
    put(img, "aur dost ko bhejo", W / 2, 1040, 56, WHITE, MED, a=eo((t - 1.1) / .4))
    pill(img, W / 2, 1385, 820 * (1 + .04 * math.sin(t * 6)), 220, CYAN, a=eo((t - 1.6) / .4), fa=70)
    put(img, "BOSS ENGLISH", W / 2, 1355, 76, WHITE, a=eo((t - 1.7) / .4)); put(img, "A C A D E M Y", W / 2, 1435, 44, CYAN, MED, a=eo((t - 1.9) / .4))
    put(img, "Follow for more", W / 2, 1640, 48, WHITE, REG, a=eo((t - 2.4) / .4))

def frame(f, ms):
    t = f / FPS; img = bg(t)
    if t < 2.6: hook(img, t)
    for i, (a, b) in enumerate(SM):
        if a <= t < b: mistake(img, t - a, ms[i], i)
    if t >= CTA: cta(img, t - CTA)
    if t < CTA: put(img, "Boss English Academy", W / 2, 1780, 36, WHITE, MED, a=.55)
    lay = Image.new("RGBA", (W, 40), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    d.rounded_rectangle([60, 10, W - 60, 22], radius=6, fill=(255, 255, 255, 45)); d.rounded_rectangle([60, 10, 60 + (W - 120) * t / DUR, 22], radius=6, fill=CYAN + (255,))
    img.alpha_composite(lay, (0, 60)); return img.convert("RGB")

def audio(path, voice):
    sr = 44100; n = int(sr * DUR); x = np.zeros(n, np.float32); beat = 60 / 104
    def add(sig, st, g=1.0, buf=x):
        s = int(st * sr); e = min(n, s + len(sig))
        if 0 <= s < n: buf[s:e] += sig[:e - s] * g
    T = lambda d: np.arange(int(d * sr)) / sr
    t = T(.28); kick = (np.sin(2 * np.pi * np.cumsum(120 * np.exp(-t * 18) + 45) / sr) * np.exp(-t * 9) * .95).astype(np.float32)
    t = T(.06); hat = (np.random.randn(len(t)) * np.exp(-t * 70) * .18).astype(np.float32)
    t = T(.2); snr = ((np.random.randn(len(t)) * .4 + np.sin(2 * np.pi * 190 * t) * .3) * np.exp(-t * 20) * .5).astype(np.float32)
    def bass(fr, d):
        t = T(d); return ((np.sin(2 * np.pi * fr * t) + .3 * np.sin(4 * np.pi * fr * t)) * np.minimum(1, t * 80) * np.exp(-t * 3.5) * .35).astype(np.float32)
    def pluck(fr):
        t = T(.35); return ((np.sign(np.sin(2 * np.pi * fr * t)) * .5 + np.sin(4 * np.pi * fr * t) * .3) * np.exp(-t * 9) * .16).astype(np.float32)
    roots = [220.0, 220.0, 261.63, 196.0]; arp = [440.0, 523.25, 659.25, 523.25, 392.0, 493.88, 587.33, 493.88]
    for bar in range(int(DUR / (beat * 4)) + 1):
        t0 = bar * beat * 4
        for q in range(4):
            tt = t0 + q * beat; add(kick if q in (0, 2) else snr, tt); add(hat, tt); add(hat, tt + beat / 2); add(bass(roots[bar % 4], beat * .9), tt)
        for e in range(8): add(pluck(arp[(e + bar * 2) % 8]), t0 + e * beat / 2)
    def whoosh(st): m = T(.35); add((np.random.randn(len(m)) * np.sin(np.pi * m / .35) * .25).astype(np.float32), st)
    def pop(st, fr=900): t = T(.12); add((np.sin(2 * np.pi * (fr + 2500 * t) * t) * np.exp(-t * 35) * .5).astype(np.float32), st)
    def ding(st): t = T(.6); add(((np.sin(2 * np.pi * 1318 * t) + .5 * np.sin(2 * np.pi * 1975 * t)) * np.exp(-t * 6) * .28).astype(np.float32), st)
    whoosh(0); pop(.45, 700)
    for a, b in SM: whoosh(a); pop(a + .1, 600); pop(a + 1, 300); ding(a + 1.4); pop(a + 2, 1000)
    whoosh(CTA); ding(CTA + .8); pop(CTA + 1.6, 800)
    x *= np.minimum(1, (DUR - np.arange(n) / sr) / .8).astype(np.float32); x = x / (np.abs(x).max() + 1e-6) * .85
    ok = False
    if voice:
        try:
            import edge_tts
            vo = np.zeros(n, np.float32); tmp = tempfile.mkdtemp()
            async def go():
                for k, (st, tx) in enumerate(voice):
                    p = f"{tmp}/v{k}.mp3"; await edge_tts.Communicate(tx, "en-GB-SoniaNeural", rate="-5%").save(p)
                    raw = subprocess.run(["ffmpeg", "-loglevel", "error", "-i", p, "-f", "f32le", "-ar", str(sr), "-ac", "1", "-"], capture_output=True, check=True).stdout
                    add(np.frombuffer(raw, np.float32), st, 1.0, vo)
            asyncio.run(go()); x = x * .45 + vo / (np.abs(vo).max() + 1e-6) * .9; x = np.clip(x, -1, 1); ok = True
        except Exception as e: print("voice skipped:", e)
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr); w.writeframes((x * 32767).astype(np.int16).tobytes())
    return ok

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--date", default=""); ap.add_argument("--out", default="reels"); ap.add_argument("--novoice", action="store_true")
    a = ap.parse_args()
    d = a.date or datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=5, minutes=30))).strftime("%Y-%m-%d")
    doy = datetime.date.fromisoformat(d).timetuple().tm_yday; N = len(POOL)
    ms = [POOL[(doy * 3 + i) % N] for i in range(3)]; song = SONGS[doy % len(SONGS)]
    os.makedirs(a.out, exist_ok=True); mp4 = f"{a.out}/{d}.mp4"; wav = f"/tmp/modern_{d}.wav"
    voice = None if a.novoice else [(.4, "Stop! Three common English mistakes.")] + [(SM[i][0] + 1.5, f"Say, {ms[i][1]}.") for i in range(3)] + [(CTA + .9, "Save this reel, and follow Boss English Academy.")]
    vok = audio(wav, voice)
    p = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-", "-i", wav,
                          "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", mp4], stdin=subprocess.PIPE)
    for f in range(int(FPS * DUR)): p.stdin.write(frame(f, ms).tobytes())
    p.stdin.close()
    if p.wait() != 0: raise SystemExit("ffmpeg failed")
    lines = "\n".join(f"❌ {m[0]}  ✅ {m[1]}" for m in ms)
    cap = (f"3 common English mistakes - kya aap bhi karte ho?\n\n{lines}\n\nSpoken English Online Classes join karne ke liye WhatsApp karein:\nPremium class: +91 89495 17193\n"
           "WhatsApp Group: https://chat.whatsapp.com/D5V1RJRbbJh25jCdU3doQd\nWhatsApp Channel: https://whatsapp.com/channel/0029Vb9OCDSKrWQxr7pqsW2B\nTelegram: https://t.me/bossenglishacademy\n\n"
           f"Motivational English song: {song}\n\n#spokenenglish #learnenglish #englishspeaking #englishlearning #englishgrammar #commonmistakes #englishwithme #spokenenglishclass #bossenglishacademy #reels #english")
    json.dump({"date": d, "type": "modern_mistakes", "title": " | ".join(m[1] for m in ms), "voice": "en-GB-SoniaNeural", "voice_ok": vok, "seconds": DUR, "caption": cap}, open(f"{a.out}/{d}.json", "w"), ensure_ascii=False)
    print("OK", mp4, "voice_ok=", vok)
main()
