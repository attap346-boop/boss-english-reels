"""Shadowing-practice reel: British voice reads a short passage line by line,
with a pause after each line for the viewer to repeat."""
import json
import os

from make_boss_reel import (tts, silence, run, dur, new_frame, block, chip, scene_cta,
                            GOLD, WHITE, GREY, GREEN, W, H, NL, PHONE, SONGS, LINKS, TAGS)

DIM = (105, 120, 155)


def hook_frame(item):
    img, d = new_frame()
    chip(d, "SHADOWING PRACTICE", 420)
    y = block(d, [(w, WHITE) for w in "Repeat after me".split()], True, 120, 80, W - 200, 400, 640)
    y = block(d, [(w, GOLD) for w in "Speak like a native".split()], True, 64, 44, W - 200, 200, y + 30)
    y = block(d, [(w, GREY) for w in ("Topic: " + item["title"]).split()], True, 54, 38, W - 200, 200, y + 90)
    block(d, [(w, WHITE) for w in item["hindi"].split()], False, 54, 38, W - 200, 200, y + 10, 1.45)
    return img


def line_frame(item, cur, mode):
    img, d = new_frame()
    chip(d, "SHADOWING PRACTICE", 300)
    block(d, [(w, GREY) for w in item["title"].split()], True, 46, 34, W - 200, 100, 420)
    y = 560
    for i, ln in enumerate(item["lines"]):
        if i == cur:
            col = WHITE if mode == "listen" else GOLD
        else:
            col = DIM
        y = block(d, [(w, col) for w in ln.split()], True, 60, 40, W - 180, 260, y) + 28
    if mode == "listen":
        chip(d, "LISTEN", 1580, GREY)
    else:
        chip(d, "NOW YOU REPEAT", 1580, GREEN)
    return img


def build(item, date, day, voice, out, audio):
    tmp = os.path.join(out, ".tmp-" + str(date))
    os.makedirs(tmp, exist_ok=True)
    oks, parts, scenes = [], [], []

    d, ok = tts("Shadowing practice. Topic: " + item["title"] + ". Repeat after me.", voice, "-5%", False, tmp + "/hook.wav")
    oks.append(ok)
    parts += [tmp + "/hook.wav", silence(0.8, tmp + "/h1.wav")]
    scenes.append((hook_frame(item), d + 0.8))

    for i, ln in enumerate(item["lines"]):
        d, ok = tts(ln, voice, "-10%", False, tmp + "/l%d.wav" % i)
        oks.append(ok)
        gap = max(2.6, d * 1.15 + 0.8)
        parts += [silence(0.3, tmp + "/p%d.wav" % i), tmp + "/l%d.wav" % i, silence(gap, tmp + "/g%d.wav" % i)]
        scenes.append((line_frame(item, i, "listen"), 0.3 + d))
        scenes.append((line_frame(item, i, "repeat"), gap))

    d, ok = tts("Join our online spoken English classes. Message Boss English Academy on WhatsApp.", voice, "-5%", False, tmp + "/cta.wav")
    oks.append(ok)
    tail = max(1.0, 3.5 - d)
    parts += [tmp + "/cta.wav", silence(tail, tmp + "/t.wav")]
    scenes.append((scene_cta(), d + tail))

    lst = tmp + "/list.txt"
    with open(lst, "w") as f:
        for p in parts:
            f.write("file '" + os.path.abspath(p) + "'" + NL)
    voice_wav = tmp + "/voice.wav"
    run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", voice_wav])

    total = sum(s[1] for s in scenes)
    cmd = ["ffmpeg", "-y", "-loglevel", "error"]
    for i, (im, dd) in enumerate(scenes):
        p = tmp + "/s%d.png" % i
        im.save(p)
        cmd += ["-loop", "1", "-framerate", "30", "-t", str(round(dd, 2)), "-i", p]
    n = len(scenes)
    room = int(dur(audio)) - (int(total) + 4)
    start = (day * 37) % room if room > 0 else 0
    cmd += ["-ss", str(start), "-i", audio, "-i", voice_wav]
    vf = "".join("[%d:v]fade=t=in:st=0:d=0.2,setsar=1[v%d];" % (i, i) for i in range(n))
    vf += "".join("[v%d]" % i for i in range(n)) + "concat=n=%d:v=1:a=0,format=yuv420p[v];" % n
    vf += ("[%d:a]volume=0.10,afade=t=in:st=0:d=1,afade=t=out:st=%s:d=1.5[m];"
           "[%d:a]volume=1.0[vo];[m][vo]amix=inputs=2:duration=longest:normalize=0[a]") % (n, round(total - 1.5, 2), n + 1)
    mp4 = os.path.join(out, str(date) + ".mp4")
    cmd += ["-filter_complex", vf, "-map", "[v]", "-map", "[a]", "-t", str(round(total, 2)),
            "-c:v", "libx264", "-r", "30", "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-ac", "2",
            "-movflags", "+faststart", mp4]
    run(cmd)

    cap = ("Shadowing Practice: " + item["title"] + NL + item["hindi"] + NL + NL + NL.join(item["lines"]) + NL + NL +
           "How to practise: listen to each line, then repeat it aloud in the same speed and tone. 5 minutes daily makes a big difference." + NL + NL +
           "Spoken English Online Classes join karne ke liye WhatsApp karein:" + NL + "Premium class: " + PHONE + NL + LINKS + NL + NL +
           "Motivational English song: " + SONGS[day % len(SONGS)] + NL + NL +
           "#shadowing #shadowingpractice #speakenglish #spokenenglish #britishaccent #learnenglish #englishspeaking #bossenglishacademy #reels")
    meta = {"date": str(date), "type": "shadow", "title": item["title"], "voice": voice,
            "voice_ok": all(oks), "seconds": round(total, 1), "caption": cap}
    with open(os.path.join(out, str(date) + ".json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False)
    for fn in os.listdir(tmp):
        os.remove(os.path.join(tmp, fn))
    os.rmdir(tmp)
    print("built shadow", date, item["title"], "voice_ok", meta["voice_ok"], "total", round(total, 1))
